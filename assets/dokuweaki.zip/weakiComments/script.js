jQuery(document).ready(function() {

	var visibleNewCommentDialogID;

	/*
	* Opens comments container on comment trigger hovering.
	*/
	jQuery('.comment-trigger').hover(function() {
		jQuery(this).parent().siblings('.comments-container').slideDown();
	}, function() {
		jQuery(this).parent().siblings('.comments-container').slideUp();
	});

	/*
	* Opens a new comment dialog when a comment trigger is clicked.
	*/
	jQuery('.comment-trigger').click(function() {
		visibleNewCommentDialogID = jQuery(this).data('val');
		jQuery('#new-comment-dialog-' + visibleNewCommentDialogID).fadeIn(150);
	});

	jQuery(document).mouseup(function(e) {
		/*
		* Closes a new comment dialog if a mouse click is registered
		* outside the currently opened new comment dialog or comment trigger.
		*/
		if (mouseClickOutsideContainer(e, jQuery('#comment-trigger-' + visibleNewCommentDialogID))) {
			var container = jQuery('.new-comment-dialog');

			if (mouseClickOutsideContainer(e, container))
				container.fadeOut();
		}
	});

	jQuery('.submitComment').click(function() {
		var commentText = jQuery(this).prev().val();

		var filteredHtml = jQuery('.page.group').clone();
		filteredHtml.find('#dw__toc').remove();
		filteredHtml.find('.new-comment-dialog').remove();
		filteredHtml.find('.comment-trigger').remove();
		filteredHtml.find('button').remove();
		filteredHtml.find('.js-code').remove();
		filteredHtml = filteredHtml.html();
		//console.log(filteredHtml);

		var plainHtml = htmlToPlaintext(filteredHtml);
		//console.log(plainHtml);

		var htmlLinesArray = plainHtml.split(/\r\n|\r|\n/);
		//console.log(htmlLinesArray);

		var commentLine = -1;
		for (var i = 0; i < htmlLinesArray.length; i++) {
			if (htmlLinesArray[i].search('comment-trigger-' + visibleNewCommentDialogID) != -1) {
				commentLine = i;
				break;
			}	
		}

		if (commentLine == -1) {
			console.log("bad button line for comment add");
			return;
		}

		//console.log('Line: ' + commentLine);
		//return;

		var commentPage = "start";
		if(QueryString.id != null) {
			commentPage = QueryString.id;
			commentPage = commentPage.replace(':', '/');
		}

		jQuery.post(
			DOKU_BASE + 'lib/exe/ajax.php', {
				call: 'comments_add',
				commentDate: new Date().toString(),
				commentLine: commentLine,
				commentPage: commentPage,
				commentText: commentText
			}, function(data) {
				window.location.reload();
			}, 'json');
	});

	/*
	* Wraps groups of adjacent comments in a container.
	*/
	var commentsContainer = [];
	jQuery('.comment').each(function() {
		var nextComment = jQuery(this).next().hasClass('comment');
		commentsContainer.push(jQuery(this));

		if (!nextComment) {
			var container = jQuery('<div class="comments-container"></div>');

			container.insertBefore(commentsContainer[0]);

			for (i = 0; i < commentsContainer.length; i++) {
				commentsContainer[i].appendTo(container);
			}

			commentsContainer = [];
		}
	});

});

function mouseClickOutsideContainer(e, container) {
	return !container.is(e.target) && container.has(e.target).length === 0;
}

function htmlToPlaintext(text) {
	return String(text).replace(/<br\s*[\/]?>/gi, "\n").replace(/<[^>]+>/gm, '').replace(/\n\s*\n/g, '\n');
}

/*
* This anonymous function is executed immediately and
* the return value is assigned to QueryString.
*/
var QueryString = function() {
	var query_string = {};
	var query = window.location.search.substring(1);
	var vars = query.split("&");

	for (var i = 0; i < vars.length; i++) {
		var pair = vars[i].split("=");

		if (typeof query_string[pair[0]] === "undefined") {
			// If first entry with this name

			query_string[pair[0]] = decodeURIComponent(pair[1]);

		} else if (typeof query_string[pair[0]] === "string") {
			// If second entry with this name

			var arr = [query_string[pair[0]], decodeURIComponent(pair[1])];
			query_string[pair[0]] = arr;

		} else {
			// If third or later entry with this name

			query_string[pair[0]].push(decodeURIComponent(pair[1]));

		}
	}

	return query_string;
}();

<?php
/**
 * DokuWiki Plugin weakiComments (Action Component)
 *
 * @license GPL 2 http://www.gnu.org/licenses/gpl-2.0.html
 * @author  Anaís Dias <dias4993@gmail.com>
 * @author  Gabriel Souto <ei12087@fe.up.pt>
 * @author  João Bordalo <bordalo.joao94@gmail.com>
 * @author  Pedro Castro <pedromrvc@gmail.com>
 */

// must be run within Dokuwiki
if(!defined('DOKU_INC')) die();
if(!defined('DOKU_PLUGIN')) define('DOKU_PLUGIN',DOKU_INC.'lib/plugins/');
require_once (DOKU_PLUGIN . 'action.php');

class action_plugin_weakiComments extends DokuWiki_Action_Plugin {

    /**
     * Registers a callback function for a given event
     *
     * @param Doku_Event_Handler $controller DokuWiki's event controller object
     * @return void
     */
    public function register(Doku_Event_Handler $controller) {
        $controller->register_hook('AJAX_CALL_UNKNOWN', 'BEFORE', $this, '_ajax_call');
    }

    /**
     * [Custom event handler which performs action]
     *
     * @param Doku_Event $event  event object by reference
     * @param mixed      $param  [the parameters passed as fifth argument to register_hook() when this
     *                           handler was registered]
     * @return void
     */
    public function _ajax_call(Doku_Event &$event, $param) {
        if ($event->data !== 'comments_add') {
            return;
        }

        //no other ajax handlers needed
        $event->stopPropagation();
        $event->preventDefault();

        //e.g. access additional request variables
        global $INPUT; //available since release 2012-10-13 "Adora Belle"
        $commentDate = $INPUT->str('commentDate');
        $commentLine = $INPUT->str('commentLine');
        $commentText = $INPUT->str('commentText');
        $commentPage = $INPUT->str('commentPage');

        global $USERINFO;
        $username = $USERINFO['name'] ? $USERINFO['name'] : "Anonymous";

        $file = DOKU_INC.'data/pages/'.$commentPage.'.txt';

        // Open the file to get existing content
        $fileLines = file($file, FILE_IGNORE_NEW_LINES);
        $newFileContent = "";
        $currentLine = 0; // meaningful lines counter (excludes empty lines and comments)

        // Loop through our array, show HTML source as HTML source; and line numbers too.
        foreach ($fileLines as $line) {
            // If this line is not empty and is not a comment
            if ($line != "" && !preg_match("/<cmt[\s\S]*?>[\s\S]*?<\/cmt>/", $line)) {
                if ($currentLine == $commentLine - 1) {
                    $newFileContent .= $line."\n".
                    "<cmt>".$commentDate."/".$username."/".$commentLine."/".$commentText."</cmt>"."\n";
                } else {
                    $newFileContent .= $line."\n";
                }

                $currentLine++;
            } else {
                $newFileContent .= $line."\n";
            }
        }

        file_put_contents($file, $newFileContent);
        Header('Location: '.$_SERVER['PHP_SELF']);
        Exit();
    }

}

// vim:ts=4:sw=4:et:

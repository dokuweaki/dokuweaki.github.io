<?php
/**
 * DokuWiki Plugin weakiTemplating (Action Component)
 *
 * @license GPL 2 http://www.gnu.org/licenses/gpl-2.0.html
 * @author  Diogo Gomes <di.gomes14@gmail.com>
 * @author  Eduardo Almeida <eduardomanuel1512@gmail.com>
 * @author  Joana Beleza <joanita.beleza@gmail.com>
 * @author  João Morgado <jota94mfm@gmail.com>
 */

if (!defined('DOKU_INC')) die();

/*
 *  Pattern: Proxy
 *  Provide a surrogate or placeholder for another object to control access to it.
 */

/*
 *  Pattern: Singleton
 *  Ensure a class only has one instance, and provide a global point of access to it.
 */

class TemplateAccessProxy {

    private static $instance;

    private $templateDir = 'lib/plugins/weakiTemplating/templates/';
    private $userTemplateDir = 'data/pages/templates/';

    public static function getInstance() {
        if (static::$instance === null) {
            static::$instance = new static();
        }

        return static::$instance;
    }

    protected function __construct() {}

    private function __clone() {}

    private function __wakeup() {}

    public function getTemplate($templateName) {
        if (file_exists($this->userTemplateDir . $templateName . '.txt'))
            return $this->userTemplateDir . $templateName . '.txt';
        else if (file_exists($this->templateDir . $templateName . '.txt'))
            return $this->templateDir . $templateName . '.txt';

        return null;
    }

}

class action_plugin_weakiTemplating extends DokuWiki_Action_Plugin {

    public function register(Doku_Event_Handler $controller) {
        /*
         *  Pattern: Observer / Publish-Subscribe
         *  Define a one-to-many dependency between objects so that when one object changes state, all its dependents are notified and updated automatically.
         */

        $controller->register_hook('COMMON_PAGETPL_LOAD', 'BEFORE', $this, 'handle_weaki_before_pagetpl_load');
    }

    public function handle_weaki_before_pagetpl_load(Doku_Event &$event, $param) {
        global $conf;

        if (!empty($event->data['tplfile']))
            return;

        $id_parts = explode('.', $event->data['id']);

        $tpl_name = $id_parts[count($id_parts) - 1];

        $tpl_proxy = TemplateAccessProxy::getInstance();

        if (( $p = $tpl_proxy->getTemplate($tpl_name) ))
            $event->data['tplfile'] = $p;
    }

}

<?php

$lang['github_token'] = "GitHub user token - https://github.com/settings/tokens";
$lang['github_repository'] = "GitHub repository";

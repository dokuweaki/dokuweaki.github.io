<?php

class Command
{
    public static function callCommand($command){
        return $command->execute();
    }
}

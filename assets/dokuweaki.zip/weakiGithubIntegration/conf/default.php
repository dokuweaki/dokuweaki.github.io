<?php

$conf['github_token'] = '<token>';
$conf['github_repository'] = '<username>/<repository>';

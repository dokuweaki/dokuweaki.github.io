<?php

$meta['github_token'] = array('string');
$meta['github_repository'] = array('string');

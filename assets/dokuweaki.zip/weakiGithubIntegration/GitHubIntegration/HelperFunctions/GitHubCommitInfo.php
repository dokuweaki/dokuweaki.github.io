<?php

class GitHubCommitInfo
{
    /**
     * @param $github
     * @param $commitMessage
     * @param $commitContent
     * @param $committer
     * @return array
     */
    public static function generateCommitInformation($github, $commitMessage, $commitContent, $committer){

        $data = [
            'message' => $commitMessage,
            'committer' => $committer,
        ];

        if($github->hasFileSHA()){
            $data["sha"] = $github->getFileSHA();
        }

        if ($commitContent != "") {
            $data["content"] = base64_encode($commitContent);
        }

        return $data;
    }
}
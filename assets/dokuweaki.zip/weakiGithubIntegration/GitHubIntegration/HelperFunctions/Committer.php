<?php

class Committer
{

    /**
     * @return array with the user name and user email
     */
    public static function getCommiter(){

        global $USERINFO;

        $committer = [
            'name'  => $USERINFO["name"],
            'email' => $USERINFO["mail"],
        ];

        return $committer;
    }
}
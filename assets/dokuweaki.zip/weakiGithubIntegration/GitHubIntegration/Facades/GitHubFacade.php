<?php


class GitHubFacade
{
    /**
     * @param $command
     * @return array
     */
    public static function generateRequest($command){
        $committer = Committer::getCommiter();
        $data = GitHubCommitInfo::generateCommitInformation($command->github, $command->commitMessage, $command->commitContent, $committer);
        return $data;
    }

    /**
     * @param $github GitHubIntegration object
     * @param $event DokuWikiEvent object
     * @param int $type The type used in GitHubCommandFactory to create a GitHubCommand
     * @return mixed
     */
    public static function CallCommand($github, $event, $type = 0){
        $command = GitHubCommandFactory::create($github, $event, $type);
        return Command::callCommand($command);
    }

}
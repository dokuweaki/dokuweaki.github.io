<?php

class GitHubPullCommand extends GitHubCommand
{

    /**
     * Returns the file information that is currently in the GitHub repository
     *
     * @return \Milo\Github\Http\Response
     */
    function execute()
    {
        $repoPath = $this->github->getReposPathToFile($this->file);
        try {
            $response = $this->github->api->get($repoPath);
            $file = $this->github->api->decode($response);
            $content = base64_decode($file->content);

            $this->github->fileSHA = $file->sha;

            return $content;
        }
        catch(Exception $e) {
            return "";
        }
    }
}
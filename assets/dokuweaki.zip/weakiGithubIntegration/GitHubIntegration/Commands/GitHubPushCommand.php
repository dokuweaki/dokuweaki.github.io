<?php


class GitHubPushCommand extends GitHubCommand
{
    /**
     * Pushes the information of the current page to GitHub and sets the file to null afterwards
     */
    function execute()
    {
        $request = GitHubFacade::generateRequest($this);
        $path = $this->github->getReposPathToFile($this->file);

        $this->github->api->put($path, $request);

        $this->github->setFileSHA(null);
    }
}

<?php

class GitHubDeleteCommand extends GitHubCommand
{

    /**
     * Deletes the current file that is present in the GitHub repository
     *
     * @return \Milo\Github\Http\Response
     */
    function execute()
    {
        $request = GitHubFacade::generateRequest($this);
        $path = $this->github->getReposPathToFile($this->file);
        $response = $this->github->api->delete($path, $request);

        $this->github->setFileSHA(null);

        return $response;
    }
}
<?php

abstract class GitHubCommand
{

    public $github;

    public $file;
    public $commitMessage = null;
    public $commitContent = null;
    public $contentChanged = false;

    /**
     * GitHubCommand constructor.
     * @param GitHubIntegration $github
     * @param $file
     * @param null $commitMessage
     * @param null $commitContent
     * @param bool $contentChanged
     */
    function __construct(GitHubIntegration $github, $file, $commitMessage = null, $commitContent = null, $contentChanged = false) {
        $this->github = $github;
        $this->file = $file;
        $this->commitMessage = $commitMessage;
        $this->commitContent = $commitContent;
        $this->contentChanged = $contentChanged;
    }

    abstract function execute();
}

<?php



class GitHubCommandFactory
{
    /**
     * @param $github GitHubIntegration object
     * @param $event DokuWikiEvent object
     * @param int $type Type of command. 0 -> push/delete ; 1 -> pull
     * @return GitHubDeleteCommand|GitHubPullCommand|GitHubPushCommand|null
     */
    public static function create($github, $event, $type = 0)
    {

        switch($type){
            case 0:
                if($event->data["newContent"] == "")
                {
                    return new GitHubDeleteCommand($github, $event->data["file"],
                                            $event->data["summary"], $event->data["newContent"],
                                            $event->data["contentChanged"]);
                }else{
                    return new GitHubPushCommand($github, $event->data["file"],
                                          $event->data["summary"], $event->data["newContent"],
                                          $event->data["contentChanged"]);
                }
                break;

            case 1:
                return new GitHubPullCommand($github, $event->data[0][0]);
                break;
        }

        return null;
    }
}
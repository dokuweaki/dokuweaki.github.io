<?php

class GitHubFactory
{
    /**
     * @param $repos
     * @param $tokenString
     * @return GitHubIntegration
     */
   public static function create($repos, $tokenString)
   {
       $repo = "/repos/" . $repos . "/contents/";
       return new GitHubIntegration($repo, $tokenString);
   }
}

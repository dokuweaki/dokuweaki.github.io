<?php

use Milo\Github;


class GitHubIntegration
{
  public $token;
  public $api;
  public $fileSHA;
  public $repos;

  /**
   * GitHubIntegration constructor.
   *
   * @param $repos
   * @param $tokenString
   */
  public function __construct($repos, $tokenString)
  {
    $this->token = new Milo\Github\OAuth\Token($tokenString);
    $this->api = new Github\Api;
    $this->api->setToken($this->token);
    $this->repos = $repos;
  }

  /**
   * @return bool
   */
  public function hasFileSHA(){
    return isset($this->fileSHA);
  }

  /**
   * @return mixed
   */
  public function getFileSHA(){
    return $this->fileSHA;
  }

  /**
   * @param $null
   */
  public function setFileSHA($null)
  {
    $this->fileSHA = null;
  }
  

  /* AUXILIARY METHODS */

  /**
   * Returns the correct path to a specific file in the needed structure
   *
   * @param $file
   * @return string
   */
  public function getPathToFile($file){
      return substr($file, strrpos($file, '/data/pages/') + 12);
  }

  /**
   * Return the current repository path plus the file path
   *
   * @param $file
   * @return string
   */
  public function getReposPathToFile($file){
      $path = $this->getPathToFile($file);
      return $this->repos . $path;
  }


}


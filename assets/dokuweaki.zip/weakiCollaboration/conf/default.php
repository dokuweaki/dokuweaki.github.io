<?php

$conf['sharejs_server_domain'] = '192.168.1.5';

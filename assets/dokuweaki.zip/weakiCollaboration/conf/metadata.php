<?php

$meta['sharejs_server_domain'] = array('string');

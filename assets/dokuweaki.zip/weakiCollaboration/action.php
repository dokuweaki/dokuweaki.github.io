<?php
/**
 * DokuWiki Plugin weakiCollaboration (Action Component)
 *
 * @license GPL 2 http://www.gnu.org/licenses/gpl-2.0.html
 * @author  Henrique Ferrolho <henrique.ferrolho@gmail.com>
 */

// must be run within Dokuwiki
if(!defined('DOKU_INC')) die();

class action_plugin_weakiCollaboration extends DokuWiki_Action_Plugin {

    /**
     * Registers a callback function for a given event
     *
     * @param Doku_Event_Handler $controller DokuWiki's event controller object
     * @return void
     */
    public function register(Doku_Event_Handler $controller) {
        $controller->register_hook('TPL_METAHEADER_OUTPUT', 'BEFORE', $this, 'handle_tpl_metaheader_output');
        $controller->register_hook('DOKUWIKI_STARTED', 'AFTER',  $this, '_varpass');
    }

    /**
     * Hook js script into page headers.
     */
    public function handle_tpl_metaheader_output(Doku_Event $event, $param) {
        $domain = $this->getConf('sharejs_server_domain');

        $event->data['script'][] = array('src' => 'http://' . $domain . ':3000/channel/bcsocket.js');
        $event->data['script'][] = array('src' => 'http://' . $domain . ':3000/share/share.js');
        $event->data['script'][] = array('src' => 'http://' . $domain . ':3000/share/textarea.js');
    }

    function _varpass(Doku_Event $event, $param) {
        global $JSINFO;
        $JSINFO['sharejs_server_domain'] = $this->getConf('sharejs_server_domain');
    }

}

// vim:ts=4:sw=4:et:

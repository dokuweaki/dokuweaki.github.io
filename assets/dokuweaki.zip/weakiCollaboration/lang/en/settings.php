<?php

$lang['sharejs_server_domain'] = "ShareJS Server Domain";
